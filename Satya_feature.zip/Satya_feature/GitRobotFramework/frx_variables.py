
#General configuration
BROWSER =  "chrome"
TENANT  =  "frx"
URL = "http://RexelQAEnv:Rexel!23@10.240.6.252"

#Users
ACTIVE_USER = {"login":"julien.sivamalnessane-ext@rexel.com", "password" :"12345678"}




#Product data
VALID_EAN = "3410531201178"
INVALID_EAN = "3410531"
VALID_SKU = "ITR701063"
INVALID_SKU = "ITR701"
VALID_MFG = "701063"
INVALID_MFG = "70"
VALID_UPC = "NOT USED YET"
INVALID_UPC = "NOT USED YET"
MULTIPLE_REFERENCE_MFG = "700033" #Use in quickOrder to get the error of multiple reference found
MORE_THAN_ONE_SKU = "FILR2V3G2,5T500" #Use for testing that the min order qty is the good one displayed
MORE_THAN_ONE_MIN = "500"
MORE_THAN_ONE_MULTIPLE = "500"