
#General configuration
BROWSER =  "chrome"
TENANT  =  "nor"
BACKOFFICE = "norway"
URL = "http://RexelQAEnv:Rexel!23@10.240.6.252"

#Users

HMC_ADMIN_USER = {"login":"AkbarVirani", "password" :"Vh%dZcx#oq"}
ADMIN_USER = {"login":"nils.arne.grande@elektroskandia.no", "password" :"12345678"}
ACTIVE_USER = {"login":"nils.arne.grande@elektroskandia.no", "password" :"12345678"}
USER_WITH_NO_RESTRICTION_TO_CREATE_SHARED_DELIVERY_ADDRESS = {"login":"nils.arne.grande@elektroskandia.no", "password" :"12345678"}
USER_WITH_NO_RESTRICTION_TO_DELETE_SHARED_DELIVERY_ADDRESS = {"login":"nils.arne.grande@elektroskandia.no", "password" :"12345678"} #It must be a different user account on same ERP account than can access address previously created
USER_WITH_NO_SHARED_DELIVERY_ADDRESS = {"login":"nils.arne.grande@elektroskandia.no", "password" :"12345678"}

##TODO --> TO COMPLETE BELOW DUMMY DATA
#Product data
VALID_EAN = "3410531201178"
INVALID_EAN = "3410531"
VALID_SKU = "ITR701063"
INVALID_SKU = "ITR701"
VALID_MFG = "701063"
INVALID_MFG = "70"
VALID_UPC = "NOT USED YET"
INVALID_UPC = "NOT USED YET"
MULTIPLE_REFERENCE_MFG = "700033" #Use in quickOrder to get the error of multiple reference found
MORE_THAN_ONE_SKU = "FILR2V3G2,5T500" #Use for testing that the min order qty is the good one displayed
MORE_THAN_ONE_MIN = "500"
MORE_THAN_ONE_MULTIPLE = "500"



#Address data
ADDRESS_FIELDS_NAME = ["companyName", "line2", "streetName", "streetNumber", "postcode", "townCity"]
VALID_ADDRESS_VALUE = ["RINGERIKS-KRAFT" , "PRODUKSJON", "ASBJORNSENSGATE", "22-14", "3513", "HONEFOSS"]
EXTRA_SHARED_ADDRESS_FIELDS_NAME = ["informationToDriver", "packageNotes"]
VALID_EXTRA_SHARED_ADDRESS_VALUE = ["Drive well" , "this is a note"]

#User field used in users creation
USER_FIELDS_NAME = ["select:titleCode", "firstName", "lastName", "email", "uid", "password", "confirmPassword", "select:parentB2BUnit", "employeeNumber", "referenceText"]
USER_ACCESS_RIGHT_CHECKBOX_ID = ["userOnlyBrowseProductsGroup", "userWithoutHistoryGroup", "userWithoutPricesGroup", "userWithoutStockGroup", "userWithoutDownloadGroup", "limitUserOrderingToJoblist", "userWithoutAllProjects","noAccessToMasterCatalog", "noAccessToOffers", "userUnableToCreateOrEditSharedAddress", "userUnableToDeleteSharedAddress"]

USER_FIELDS_VALUE = ["Annet", "Robot", "Framework", "bruno.delabreteche@rexel.com","uid", "Robot123", "Robot123", "987293586","123456","I am a robot"]
USER_FULL_RIGHT_CHECKBOX = ["userOnlyBrowseProductsGroup", "userWithoutHistoryGroup", "userWithoutPricesGroup", "userWithoutStockGroup", "userWithoutDownloadGroup", "limitUserOrderingToJoblist", "userWithoutAllProjects","noAccessToMasterCatalog", "noAccessToOffers", "userUnableToCreateOrEditSharedAddress", "userUnableToDeleteSharedAddress"]
