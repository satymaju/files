
#General configuration
BROWSER =  "chrome"
TENANT  =  "aur"
URL = "http://RexelQAEnv:Rexel!23@10.240.6.252"

#Users
ACTIVE_USER = {"login":"uatuser1", "password" :"123456"}


#Product data
VALID_EAN = "8718696457092"
INVALID_EAN = "87"
VALID_SKU = "2342081"
INVALID_SKU = "2342"
VALID_MFG = "871869649078500"
INVALID_MFG = "87186964"
VALID_UPC = "NOT USED YET"
INVALID_UPC = "NOT USED YET"
MULTIPLE_REFERENCE_MFG = "15123" #Use in quickOrder to get the error of multiple reference found
MORE_THAN_ONE_SKU = "75600" #Use for testing that the min order qty is the good one displayed
MORE_THAN_ONE_MIN = "100"
MORE_THAN_ONE_MULTIPLE = "100"