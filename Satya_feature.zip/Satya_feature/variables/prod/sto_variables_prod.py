#General configuration
BROWSER =  "chrome"
TENANT  =  "sto"
URL = "https://www.storel.se"

#Users
USER = {"login": "qa_user1", "password":"12345678"}
TRADE_ACCOUNT_USER = {"login": "qa_user1", "password":"12345678"}
#TRADE_ACCOUNT_USER = {"login": "rexel_igate", "password":"123456"}
SUPER_CUSTOMER_ADMIN = {"login": "superuatcustomer", "password":"12345678"}
B2B_CUSTOMER_USER = 'qa_user1'
B2B_CUSTOMER_PASSWORD = '12345678'
B2B_CUSTOMER_USER1 = 'qa_user1'
B2B_CUSTOMER_PASSWORD1 = '12345678'
USER_REXEL_ACHAT = {"login": "qa_user1", "password":"qa_user1"}
#TRADE_ACCOUNT_USER = {"login": "qa_robot", "password":"@rexelrobo123"}
USER_WITH_CREDIT_CARD_PAYMENT = {"login": "credit_card_user", "password":"@rexelrobo123"}
USER_WITH_PCARD_PAYMENT = {"login": "pcard_user", "password":"@rexelrobo123"}
SAME_DAY_PICKUP_USER = {"login": "same_day_pickup_user", "password":"12345678"}

#Cart
PRODUCT_ID = '1835067'    # GENERIC product ID to add to cart for all cart test 

# Navigate To 
SHIPPING_DETAIL_TAB_EDIT_BUTTON = 'DeliveryMethodsSelectionTabbed_Delivery'

# NEW REGISTRATION INFORMATION AND COMPANY DETAILS
LIST__NEW_ACCOUNT_NUMBER_REGISTRATION_NEW_VALUE=["FIRST NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123"]	
LIST__EXTRA_YOUR_COMPANY_NEW_VALUE= ["920211-7777", "920211-7777"]
LIST__EXTRA_YOUR_COMPANY_EXISTING_VALUE= ["166000", "46383"]
LIST__EXTRA_YOUR_COMPANY_USER_INFO_NEW_VALUE=["username", "password","password"]
COMPANY_DETAILS_VALUES = ["600113-7600", "559806-4441"]  #ADDING NEW COMPANY DETAILS FOR FIXES
COMPANY_DETAILS_VALUES_UNKNOWN = ["920211-7777", "920211-7777"] #Unknown erp account
AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_STEP_TWO_ID = ["registrationStep2Firstname","registrationStep2Lastname","registrationStep2Email","registrationStep2Telephone","registrationStep2Username","password","confirmPassword"]
AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_STEP_TWO_VALUE = ["Firstname_","Lastname_","ninad.a.sane@capgemini.com","+431234567890","testTest_","12345678","12345678"]

#AUTO-TRADE ACCOUNT REGISTRATION INFORMATION AND COMPANY DETAILS
AUTO_TRADE_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_ID = ["newRegForm1FirstName","newRegForm1LastName","newRegForm1Email","newRegForm1Telephone","newRegForm1MobileNumber",  "newRegForm1Password", "newRegForm1ConfirmPassword"]
AUTO_TRADE_ACCOUNT_REGISTRATION_COMPANY_FIELDS_ID = ["newRegForm1ContactPersonId","newRegForm1CompanyOrgNumber"]

#"newRegForm1Username"
AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_ID = ["regAccountNumber","regZipCode"]
AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_VALUE = ["166000", "46383"]
#AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_VALUE = ["920211-7777", "920211-7777"]

AUTO_TRADE_ACCOUNT_REGISTRATION_EXISTING_FIELDS_ID=["regAccountNumber","regZipCode"]
AUTO_TRADE_ACCOUNT_REGISTRATION_EXISTING_FIELDS_VALUE = ["166000", "46383"]
#AUTO_TRADE_ACCOUNT_REGISTRATION_EXISTING_FIELDS_VALUE = ["920211-7777", "920211-7777"]

AUTO_TRADE_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_VALUE = ["FirstName_","LastName_","12345678901","ninad.a.sane@capgemini.com","Username_", "12345678", "12345678"]

AUTO_TRADE_ACCOUNT_NEW_ERP_INFORMATIONS_VALUE = ["FIRST_NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","UID@rexel.com", "abc12345678" , "abc12345678"]
AUTO_TRADE_ACCOUNT_NEW_ERP_COMPANY_VALUE = ["7608054941", "593074-3488"]

AUTO_TRADE_ACCOUNT_EXISTING_ERP_INFORMATIONS_VALUE = ["FIRST_NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123", "abc12345678" , "abc12345678"]
#AUTO_TRADE_ACCOUNT_EXISTING_ERP_COMPANY_VALUE = ["166000", "46383"]
AUTO_TRADE_ACCOUNT_EXISTING_ERP_COMPANY_VALUE = ["920211-7777", "920211-7777"]
#["920211-7777", "920211-7777"], "UID@rexel.com", 

AUTO_TRADE_ACCOUNT_UNKNOWN_ERP_INFORMATIONS_VALUE = ["FIRST_NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123","abc12345678" , "abc12345678"]#,"UID@rexel.com"
AUTO_TRADE_ACCOUNT_UNKNOWN_ERP_COMPANY_VALUE = ["920211-7777", "920211-7777"]
#AUTO_TRADE_ACCOUNT_UNKNOWN_ERP_COMPANY_VALUE = ["166000", "46383"]
AUTO_TRADE_ACCOUNT_EXPECTED_COMPANY_VALUE = {"company" : "'Anton' Lindqvist", "business":"Ecommerce" ,"address":"Europa-Allee 50, 60327 Frankfurt am Main 60088 , Frankfurt am Main, Germany"}
#["11011", "166000"]

VISITING_ADDRESS_POPUP = ["visitingAddressForm"]
ENTER_VISITING_ADDRESS_MANUALY = ["address.companyName_del","address.line3_del","address.streetName_del","address.streetNumber_del","address.postcode_del","address.townCity_del"]
VISITING_ADDRESS_COUNTRY_DROPDOWN = ['//*[@id="add-new-visitingAddress"]//*[@class="selectedValue"]']
VISITING_ADDRESS_COUNTRY_DROPDOWN_VALUE = ['//*[@id="add-new-visitingAddress"]//*[@class="itm-1 selected hovered"]']
UPDATE_VISITING_ADDRESS_BUTTON = ['//*[@class="goog-text-highlight"]']
CHANGE_DELIVERY_ADDRESS = ['createStructureBtnDelivery']
DELIVERY_ADDRESS_FORM = ['alt-address-second-form']
ENTER_DELIVERY_ADDRESS_MANUALY = ["address.companyName_del","address.line3_del","address.streetName_del","address.streetNumber_del","address.postcode_del","address.townCity_del"]
DELIVERY_ADDRESS_COUNTRY_DROPDOWN = ['//*[@id="add-new-deliveryAddress"]//*[@class="selectedValue"]']
DELIVERY_ADDRESS_COUNTRY_DROPDOWN_VALUE = ['//*[@id="add-new-deliveryAddress"]//*[@class="itm-1 selected hovered"]']
UPDATE_DELIVERY_ADDRESS = ["addNewDeliveryAddress"]
CLOSE_VISITING_ADDRESS_FORM = ['//*[@id="add-new-visitingAddress"]//*[@class="popupCloseIconNew"]']
VISITING_ADDRESS_FORM = ["visitingAddressForm"]
COMPANY_DESIRED_CREDIT = '1000000'

#JOBLIST NAMES VALID AND INVALID
VALID_JOBLIST_NAME = 'RM'
INVALID_JOBLIST_NAME = 'MT#@$_200_'

#JOBLIST SEARCH PRODUCT TO ADD TO JOBLIST
SEARCH_PRODUCT_NAME = 'insta'
SEARCH_PRODUCT_NAME_TWO = 'cable'
SEARCH_PRODUCT_NAME_LIST = ["insta","wire","bul","nai","insta","ener","light","tool","tele","com"]  

INVALID_PRODUCT_REFERENCE = "abc"
VALID_PRODUCT_REFERENCE_SINGLE = {"Product_Reference": "937843", "Product_Quantity": "1"}

#FAST ORDER PAGE
FAST_ORDER_PAGE = '//*[@class="quick-order-wrapper"]//*[@class="page-title"]'
FAST_ORDER_PRODUCT_ID = ["partMfgCode_0","partMfgCode_1","partMfgCode_2","partMfgCode_3","partMfgCode_4","partMfgCode_5","partMfgCode_6","partMfgCode_7","partMfgCode_8","partMfgCode_9"]
FAST_ORDER_PRODUCT_QUANTITY_ID = ["quantity_0","quantity_1","quantity_2","quantity_3","quantity_4","quantity_5","quantity_6","quantity_7","quantity_8","quantity_9"]
FAST_ORDER_PRODUCT_STATUS_ID = ["status_0","status_1","status_2","status_3","status_4","status_5","status_6","status_7","status_8","status_9"]
FAST_ORDER_PRODUCT_NUMBER_FIELD_VALUE =   ["1166853",  "1166853"]
FAST_ORDER_PRODUCT_QUANTITY_FIELD_VALUE  =  ["2",   "2"]
FAST_ORDER_MULTIPLE_PRODUCT_NUMBER_FIELD_VALUE  =  ["1166853","1166853","1166853","1166853","1166853"]

#PRODUCT DATA
VALID_PRODUCT_REFERENCE_SINGLE = {"Product_Reference": "96008411", "Product_Quantity": "10", "Product_Reference1": "221415", "Product_Quantity1": "10"}
INVALID_PRODUCT_REFERENCE = {"Product_Reference": "qwerty", "Product_Quantity": "10"}
VALID_PRODUCT_REFERENCE_MULTIPLE = {"Product_Reference": "000605", "Product_Quantity": "10"}

# Add Shared Address data
LIST__VALID_ADDRESS_VALUE=["COMPANY NAME","ADDRESS_LINE_2","CONTACT_PERSON","New Value","New Value","New Value","New Value","New Value","New Value"]
LIST__EXTRA_SHARED_ADDRESS_FIELDS_VALUE= ["Info to Driver", "package note"]
ADD_ADDRESS_FIELDS =   ["address.companyName","address.line1","address.line2","address.line3","address.streetName","address.streetNumber","address.postcode","address.townCity"]
SEARCH_NEW_ADDRESS='sector 30'

# Delete Shared Address data
SEARCH_ADDRESS_TO_DELETE='sector 30'


# Update Shared Address data
SEARCH_ADDRESS_TO_UPDATE='sector 30'

#Users:
USER_WITH_PLACEORDERRIGHT_AND_MSG = 'qa1'
USER_WITHOUT_PLACEORDERRIGHT_AND_MSG = 'qa1'
USER_WITH_PLACEORDERRIGHT_AND_NO_MSG = 'qa1'
USER_WITHOUT_PLACEORDERRIGHT_AND_NO_MSG = 'qa1'

# NEW REGISTRATION INFORMATION AND COMPANY DETAILS
#LIST__NEW_ACCOUNT_NUMBER_REGISTRATION_NEW_VALUE=["FIRST NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123"]	
#LIST__EXTRA_YOUR_COMPANY_NEW_VALUE= ["11011", "166000"]
#LIST__EXTRA_YOUR_COMPANY_EXISTING_VALUE= ["46383", "166000"]
#LIST__EXTRA_YOUR_COMPANY_USER_INFO_NEW_VALUE=["username", "password","password"]

#Checkout
PAYMENT_NUMBER = '1234567890'
INVALID_PAYMENT_NUMBER = '!@#$'

#Store locator Zip code
ZIP_CODE = '10117'

#MANDATORY FIELDS ON CHECKOUT PAGE LOCATOR
ORDER_NUMBER = 'tabbedPurchaseOrderNumber'
REFERENCE_CHANTIER = 'tabbedReferenceChantier'

#ADD NEW ADDRESS DATA
ADD_NEW_ADDRESS_DATA = ["IGATE", "", "", "Link Road", "Address", "5th", "12345", "Dallas"]

#BILLING ADDRESS FIELDS LOCATOR ON ADDRESS BOOK
BILLING_ADDRESS_LIST = ["Foretagsnamn", "Telefonavisering", "Gatunamn Nummer / Adress 1", "Postnummer", "Ort", "Land"]

#CART NAME
CART_NAME = 'TestCart'

#SEARCH ON ADDRESS BOOK PAGE
COMPANY_NAME = 'IGATE'
STREET = 'Gigaplex'
POSTAL_CODE = '12345'
CITY = 'Dallas'
COUNTRY = 'Deutschland'

#RELATIONSHIP DOCUMENT
VALID_RELATIONSHIP_DOCUMENT_NAME = 'RelDoc'
INVALID_RELATIONSHIP_DOCUMENT_NAME = '@#$RelDoc_'

#FAST ORDER
FAST_ORDER_PRODUCT_ID = ["partMfgCode_0","partMfgCode_1","partMfgCode_2","partMfgCode_3","partMfgCode_4","partMfgCode_5","partMfgCode_6","partMfgCode_7","partMfgCode_8","partMfgCode_9"]
FAST_ORDER_PRODUCT_QUANTITY_ID = ["quantity_0","quantity_1","quantity_2","quantity_3","quantity_4","quantity_5","quantity_6","quantity_7","quantity_8","quantity_9"]
FAST_ORDER_PRODUCT_STATUS_ID = ["status_0","status_1","status_2","status_3","status_4","status_5","status_6","status_7","status_8","status_9"]

#Update User
UPDATE_USER_DETAILS=["First name","abhinay.jain@capgemini.com","12345678","12345678","Last name"]

#COUNTRY URL TO VERIFY JOBLIST PAGE
CURRENT_WEBSHOP_URL = 'https://www.storel.se/sto'

#ORDER HISTORY PAGINATION DROPDOWN VALUE LOCATOR BY NAME
SELECT_VALUE = '20'

SELECT_START_DATE_CALENDER = '2016-08-05'