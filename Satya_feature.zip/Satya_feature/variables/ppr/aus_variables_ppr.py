# -*- coding: utf-8 -*-
#General configuration
BROWSER =  "chrome"
TENANT  =  "aus"
URL = "http://10.240.2.6:9001"

#Users
#USER_1 = {"login": "qauser1", "password":"12345678"}  commented not in use
SUPER_CUSTOMER_ADMIN = {"login": "qauser1", "password":"123456"}
USER = {"login": "qa_user1", "password":"12345678"}
#USER = {"login": "qa_robot", "password":"@rexelrobo123"}
DISABLEDUSER = {"login": "disabled_user", "password":"@rexelrobo123"}
SUPER_CUSTOMER_ADMIN = {"login": "qauser1", "password":"12345678"}
TRADE_ACCOUNT_USER = {"login": "qa_user1", "password":"12345678"}

#Cart
PRODUCT_ID = '3408310'  # GENERIC product ID to add to cart for all cart test 

# Navigate To 
SHIPPING_DETAIL_TAB_EDIT_BUTTON = 'DeliveryMethodsSelectionTabbed_Delivery'

#ADD NEW ADDRESS DATA
ADD_NEW_ADDRESS_DATA = ["IGATE", "Gigaplex", "Gigaplex", "Link Road", "", "", "12345", "Dallas"]
ADD_ADDRESS_FIELDS =   ["address.companyName","address.line1","address.line2","address.line3","address.streetName","address.streetNumber","address.postcode","address.townCity"]

#JOBLIST NAMES VALID AND INVALID
VALID_JOBLIST_NAME = 'RM'
INVALID_JOBLIST_NAME = 'MT#@$_200_'

#Order History Data
SEARCH_ORDER_NUMBER = '359307'

#JOBLIST SEARCH PRODUCT TO ADD TO JOBLIST
SEARCH_PRODUCT_NAME = 'wire'
SEARCH_PRODUCT_NAME_TWO = 'cable'
SEARCH_PRODUCT_NAME_LIST = ["insta","cable","wire","bul","nai","ener","light","tool","tele","com","inter","bar","mot","bus","dat","driv","insta"] 

INVALID_PRODUCT_REFERENCE = "abc"
VALID_PRODUCT_REFERENCE_SINGLE = {"Product_Reference": "937843", "Product_Quantity": "1"}

#FAST ORDER PAGE
FAST_ORDER_PAGE = '//*[@class="quick-order-wrapper"]//*[@class="page-title"]'
FAST_ORDER_PRODUCT_ID = ["partMfgCode_0","partMfgCode_1","partMfgCode_2","partMfgCode_3","partMfgCode_4","partMfgCode_5","partMfgCode_6","partMfgCode_7","partMfgCode_8","partMfgCode_9"]
FAST_ORDER_PRODUCT_QUANTITY_ID = ["quantity_0","quantity_1","quantity_2","quantity_3","quantity_4","quantity_5","quantity_6","quantity_7","quantity_8","quantity_9"]
FAST_ORDER_PRODUCT_STATUS_ID = ["status_0","status_1","status_2","status_3","status_4","status_5","status_6","status_7","status_8","status_9"]
FAST_ORDER_PRODUCT_NUMBER_FIELD_VALUE =   ["3065790",  "3065790"]
FAST_ORDER_PRODUCT_QUANTITY_FIELD_VALUE  =  ["2",   "2"]    
FAST_ORDER_MULTIPLE_PRODUCT_NUMBER_FIELD_VALUE  =  ["3065790","3065790","3065790","3065790","3065790"]

#PRODUCT DATA
VALID_PRODUCT_REFERENCE_SINGLE = {"Product_Reference": "216374", "Product_Quantity": "10", "Product_Reference1": "306064", "Product_Quantity1": "10"}
INVALID_PRODUCT_REFERENCE = {"Product_Reference": "qwerty", "Product_Quantity": "10"}
VALID_PRODUCT_REFERENCE_MULTIPLE = {"Product_Reference": "000605", "Product_Quantity": "10"}

# Add Shared Address data
LIST__VALID_ADDRESS_VALUE=["COMPANY NAME","ADDRESS_LINE_2","CONTACT_PERSON","New Value","New Value","New Value","New Value","New Value","New Value"]	
LIST__EXTRA_SHARED_ADDRESS_FIELDS_VALUE= ["Info to Driver", "package note"]

SEARCH_NEW_ADDRESS='sector 30'

# Delete Shared Address data
SEARCH_ADDRESS_TO_DELETE='sector 30'

# Update Shared Address data
SEARCH_ADDRESS_TO_UPDATE='sector 30'

#Users:
USER_WITH_PLACEORDERRIGHT_AND_MSG = 'qa1'
USER_WITHOUT_PLACEORDERRIGHT_AND_MSG = 'qa1'
USER_WITH_PLACEORDERRIGHT_AND_NO_MSG = 'qa1'
USER_WITHOUT_PLACEORDERRIGHT_AND_NO_MSG = 'qa1'

#Update User
UPDATE_USER_DETAILS=["First name","abhinay.jain@capgemini.com","12345678","12345678","Last name"]

#Checkout
PAYMENT_NUMBER = '1234567890'
INVALID_PAYMENT_NUMBER = '!@#$'

#Store locator Zip code
ZIP_CODE = '1190'

#MANDATORY FIELDS ON CHECKOUT PAGE LOCATOR
ORDER_NUMBER = 'tabbedPurchaseOrderNumber'
REFERENCE_CHANTIER = 'tabbedReferenceChantier'

#ADD NEW ADDRESS DATA
ADD_NEW_ADDRESS_DATA = ["IGATE", "", "Gigaplex", "Link Road", "Fourth", "256", "12345", "Vienne"]
ADD_ADDRESS_FIELDS =   ["address.companyName","address.line1","address.line2","address.line3","address.streetName","address.streetNumber","address.postcode","address.townCity"]

#BILLING ADDRESS FIELDS LOCATOR ON ADDRESS BOOK
BILLING_ADDRESS_LIST = ["Firma", "Adresszusatz 1", "Adresszusatz 2", "//*[@id='Straße/HausNr.']", "Postleitzahl", "Ort", "Land"]

#CART NAME
CART_NAME = 'TestCart'

#SEARCH ON ADDRESS BOOK PAGE
COMPANY_NAME = 'IGATE'
STREET = 'Fourth'
POSTAL_CODE = '12345'
CITY = 'Vienne'

#Product Details Page

Cable_cut_product_id = '1669907'

#QUOTES
QUOTE_STATUS  = 'aktiv'
QUOTE_LABEL='AngebotsPos'

#PAGE TITLE
MY_QUOTE_PAGE_TITLE = 'My Quotes'
MY_ACCOUNT_PAGE_TITLE= 'Mes Adresses'

#COUNTRY URL TO VERIFY JOBLIST PAGE
CURRENT_WEBSHOP_URL = 'http://10.240.2.6:9001/aus'

#ORDER HISTORY PAGINATION DROPDOWN VALUE LOCATOR BY NAME
SELECT_VALUE = '20'
#======================
# NEW REGISTRATION INFORMATION AND COMPANY DETAILS
LIST__NEW_ACCOUNT_NUMBER_REGISTRATION_NEW_VALUE=["FIRST NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123"]	
LIST__EXTRA_YOUR_COMPANY_NEW_VALUE= ["11011", "10144"]
LIST__EXTRA_YOUR_COMPANY_EXISTING_VALUE= ["10001", "123456"]
LIST__EXTRA_YOUR_COMPANY_USER_INFO_NEW_VALUE=["username", "password","password"]

LIST_CREATE_USER_COMPANY_MANAGEMENT_ID = ["user.firstName","userlastName","userEmail","useruid","password","confirmPassword"] 
LIST_CREATE_USER_COMPANY_MANAGEMENT_VALUE = ["QA","CompanyMgmt","ninad.a.sane@capgemini.com","CM_","12345678","12345678"]
#"userCCEmail",#"ninad.a.sane@capgemini.com"

#AUTO-TRADE ACCOUNT REGISTRATION INFORMATION AND COMPANY DETAILS
AUTO_TRADE_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_ID = ["newRegForm1FirstName","newRegForm1LastName","newRegForm1Email","newRegForm1Telephone","newRegForm1MobileNumber", "newRegForm1Username", "password", "confirmPassword"]
AUTO_TRADE_ACCOUNT_REGISTRATION_COMPANY_FIELDS_ID = ["newRegForm1ContactPersonId","newRegForm1CompanyOrgNumber"]

AUTO_TRADE_ACCOUNT_EXISTING_ERP_INFORMATIONS_VALUE = ["FIRST_NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123", "UID@rexel.com", "abc12345678" , "abc12345678"]
AUTO_TRADE_ACCOUNT_EXISTING_ERP_COMPANY_VALUE = ["11011", "10144"]

AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_ID = ["regAccountNumber","regZipCode"]
AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_VALUE = ["1032505","1100"]

AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_STEP_TWO_ID = ["registrationStep2Firstname","registrationStep2Lastname","registrationStep2Email","registrationStep2Telephone","registrationStep2Username","password","confirmPassword"]
AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_STEP_TWO_VALUE = ["Firstname_","Lastname_","ninad.a.sane@capgemini.com","+431234567890","testTest_","12345678","12345678"]

AUTO_TRADE_ACCOUNT_EXISTING_ERP_COMPANY_VALUE = ["11011", "10144"]

AUTO_TRADE_ACCOUNT_UNKNOWN_ERP_INFORMATIONS_VALUE = ["FIRST_NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123", "UID@rexel.com" , "abc12345678" , "abc12345678"]
AUTO_TRADE_ACCOUNT_UNKNOWN_ERP_COMPANY_VALUE = ["11011", "10144"]
AUTO_TRADE_ACCOUNT_EXPECTED_COMPANY_VALUE = {"company" : "New Company Name", "business":"Ecommerce" ,"address":"Europa-Allee 50, 60327 Frankfurt am Main 60088 , Frankfurt am Main, Germany"}

VISITING_ADDRESS_POPUP = ["visitingAddressForm"]
ENTER_VISITING_ADDRESS_MANUALY = ["address.companyName_del"    "address.line3_del"    "address.streetName_del"    "address.streetNumber_del"    "address.postcode_del"    "address.townCity_del"]
VISITING_ADDRESS_COUNTRY_DROPDOWN = ['//*[@id="add-new-visitingAddress"]//*[@class="selectedValue"]']
VISITING_ADDRESS_COUNTRY_DROPDOWN_VALUE = ['//*[@id="add-new-visitingAddress"]//*[@class="itm-1 selected hovered"]']
UPDATE_VISITING_ADDRESS_BUTTON = ['//*[@class="goog-text-highlight"]']
CHANGE_DELIVERY_ADDRESS = ['createStructureBtnDelivery']
DELIVERY_ADDRESS_FORM = ['alt-address-second-form']
ENTER_DELIVERY_ADDRESS_MANUALY = ["address.companyName_del"    "address.line3_del"    "address.streetName_del"    "address.streetNumber_del"    "address.postcode_del"    "address.townCity_del"]
DELIVERY_ADDRESS_COUNTRY_DROPDOWN = ['//*[@id="add-new-deliveryAddress"]//*[@class="selectedValue"]']
DELIVERY_ADDRESS_COUNTRY_DROPDOWN_VALUE = ['//*[@id="add-new-deliveryAddress"]//*[@class="itm-1 selected hovered"]']
UPDATE_DELIVERY_ADDRESS = ["addNewDeliveryAddress"]
CLOSE_VISITING_ADDRESS_FORM = ['//*[@id="add-new-visitingAddress"]//*[@class="popupCloseIconNew"]']
VISITING_ADDRESS_FORM = ["visitingAddressForm"]


# NEW REGISTRATION INFORMATION AND COMPANY DETAILS
LIST__NEW_ACCOUNT_NUMBER_REGISTRATION_NEW_VALUE=["FIRST NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123"]	
LIST__EXTRA_YOUR_COMPANY_NEW_VALUE= ["11011", "10144"]
LIST__EXTRA_YOUR_COMPANY_EXISTING_VALUE= ["10001", "123456"]
LIST__EXTRA_YOUR_COMPANY_USER_INFO_NEW_VALUE=["username", "password","password"]

SELECT_START_DATE_CALENDER = '05.08.2016'