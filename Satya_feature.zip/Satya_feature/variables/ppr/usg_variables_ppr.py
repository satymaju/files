#General configuration
BROWSER =  "chrome"
TENANT  =  "usg"
URL = "http://10.98.0.171:9001"
#General configuration
#BROWSER =  "chrome"
#TENANT  =  "usg"
#URL = "https://www.gexpro.com"

#Users
USER = {"login": "testrelease", "password":"12345678"}
TRADE_ACCOUNT_USER = {"login": "testrelease", "password":"12345678"}
SUPER_CUSTOMER_ADMIN = {"login": "superuatcustomer", "password":"12345678"}
B2B_CUSTOMER_USER = 'qa_user1'
B2B_CUSTOMER_PASSWORD = '12345678'
B2B_CUSTOMER_USER1 = 'qa_user1'
B2B_CUSTOMER_PASSWORD1 = '12345678'
USER_REXEL_ACHAT = {"login": "qa_user1", "password":"qa_user1"}
USER_WITH_CREDIT_CARD_PAYMENT = {"login": "credit_card_user", "password":"@rexelrobo123"}
USER_WITH_PCARD_PAYMENT = {"login": "pcard_user", "password":"@rexelrobo123"}
SAME_DAY_PICKUP_USER = {"login": "same_day_pickup_user", "password":"12345678"}

#Project Search Terms
#PROJECT_NUMBER = '669889'	
#PROJECT_NAME = '500 E REYNOLDS RD-669889'
PARTIAL_PROJECT_NUMBER = '66'
PARTIAL_PROJECT_NAME = 'APOLLO'
PROJECT_SEARCHBOX_THRASHHOLD = '7'

#JOBLIST NAMES VALID AND INVALID
VALID_JOBLIST_NAME = 'RM'
INVALID_JOBLIST_NAME = 'MT#@$_200_'

#PRODUCT DATA
PRODUCT_ID = '711643'

#CART NAME
CART_NAME = 'TestCart'

#PRODUCT
SEARCH_PRODUCT_NAME_LIST = ["cable","wire","bul","nai","insta","ener","light","tool","tele","com"] 

#FAST ORDER
FAST_ORDER_PRODUCT_ID = ["partMfgCode_0","partMfgCode_1","partMfgCode_2","partMfgCode_3","partMfgCode_4","partMfgCode_5","partMfgCode_6","partMfgCode_7","partMfgCode_8","partMfgCode_9"]
FAST_ORDER_PRODUCT_QUANTITY_ID = ["quantity_0","quantity_1","quantity_2","quantity_3","quantity_4","quantity_5","quantity_6","quantity_7","quantity_8","quantity_9"]
FAST_ORDER_PRODUCT_STATUS_ID = ["status_0","status_1","status_2","status_3","status_4","status_5","status_6","status_7","status_8","status_9"]
FAST_ORDER_MULTIPLE_PRODUCT_NUMBER_FIELD_VALUE  =  ["306570","306570","306570","306570","306570"]

FAST_ORDER_PRODUCT_NUMBER_FIELD_VALUE =   ["306570",  "306570"]
FAST_ORDER_PRODUCT_QUANTITY_FIELD_VALUE  =  ["2",  "2"] 

# NEW REGISTRATION INFORMATION AND COMPANY DETAILS
LIST__NEW_ACCOUNT_NUMBER_REGISTRATION_NEW_VALUE=["FIRST NAME1","SURNAME1","EMAIL1@GMAIL.COM","46705689123","46705689123"]	
LIST__EXTRA_YOUR_COMPANY_NEW_VALUE= ["11011", "10144"]
LIST__EXTRA_YOUR_COMPANY_EXISTING_VALUE= ["10001", "123456"]
LIST__EXTRA_YOUR_COMPANY_USER_INFO_NEW_VALUE=["username", "password","password"]

LIST_CREATE_USER_COMPANY_MANAGEMENT_ID = ["user.firstName","userlastName","userEmail","useruid","password","confirmPassword"] 
LIST_CREATE_USER_COMPANY_MANAGEMENT_VALUE = ["QA","CompanyMgmt","ninad.a.sane@capgemini.com","CM_","12345678","12345678"]

#QUOTES
QUOTE_STATUS  = 'QTE'
QUOTE_NAME_INPUT	= 'QUOTE123'
JOB_NAME ='AUTOMATION QUOTE'
QUOTE_DESCRIPTION = 'AUTOMATION SCRIPT GENERATED QUOTE AND CAN BE DELETED'
RFQ_SUBMITTED_MESSAGE = 'Your quote has been submitted and your cart is now empty'
RFQ_VENDOR_NAME = 'Honeywell'
RFQ_POPUP_QUANTITY = '10'
RFQ_POPUP_PRODUCT_DESCRIPTION = 'Special order item to be added to the cart for RFQ'
SPECIAL_ORDER_PRODUCT_QUOTE = 'Special Order Item'
QUOTE_LABEL ='Quote Product'

#PAGE TITLE
MY_QUOTE_PAGE_TITLE = 'Quote History'

#Checkout
PAYMENT_NUMBER = '1234567890'
INVALID_PAYMENT_NUMBER = '!@#$'
REFERENCE_CHANTIER_NUMBER = '23456789'
ENTER_NEW_DELIVERY_ADDRESS_DATA = ['QA Rexel','test','RUE DE LA FONTAINE','France','77240','CESSON','Capgemini']
ENTER_NEW_DELIVERY_ADDRESS_ID = ['address.line1_del','address.line2_del','address.line3_del','address.postcode_del','address.townCity_del']
SELECT_COUNTRY_DELIVERY_ADDRESS = 'US'

#CONTACT INFO TAB DATA
COMPANY_NAME = 'REXEL CRA'
ATTENTION_LINE = 'WEB ORDER'

#DELIVERY ADDRESS DATA FOR WEB ACCOUNT USER
WEB_ACCOUNT_DELIVERY_ADDRESS_DATA = ["", "Montfort", "Street", "", "Dallas", "75254"]

#BILLING ADDRESS DATA FOR WEB ACCOUNT USER
WEB_ACCOUNT_BILLING_ADDRESS_DATA = ["Rexel Canada", "Fifth Avenue", "Street", "Surrey", "67899"]

#CREDIT CARD DATA FOR WEB ACCOUNT USER
#CREDIT CARD DATA FOR WEB ACCOUNT USER
CREDIT_CARD_DATA = ["John Doe", "4400000000000008", "08", "2018", "737"]

#AUTO-TRADE ACCOUNT REGISTRATION INFORMATION AND COMPANY DETAILS
AUTO_TRADE_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_ID = ["newRegForm1FirstName","newRegForm1LastName","newRegForm1Telephone","newRegForm1Email","newRegForm1Username", "Password", "ConfirmPassword"]
AUTO_TRADE_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_VALUE = ["FirstName_","LastName_","12345678901","ninad.a.sane@capgemini.com","Username_", "12345678", "12345678"]
AUTO_TRADE_ACCOUNT_REGISTRATION_COMPANY_FIELDS_ID = ["newRegForm1ContactPersonId","newRegForm1CompanyOrgNumber"]

AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_ID = ["regAccountNumber","regZipCode"]
AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_VALUE = ["669889","71923"]

AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_STEP_TWO_ID = ["registrationStep2Firstname","registrationStep2Lastname","registrationStep2Email","registrationStep2Telephone","registrationStep2Username","Password","Confirmpassword"]
AUTO_TRADE_ACCOUNT_EXISTING_ACCOUNT_REGISTRATION_INFORMATIONS_FIELDS_STEP_TWO_VALUE = ["Firstname_","Lastname_","ninad.a.sane@capgemini.com","8666680721","testTest_","12345678","12345678"]

#DATA TO LINK WITH TRADE ACCOUNT USER
ACCOUNT_NUMBER = '669888'
ZIPCODE = '15212'

#Cart
PRODUCT_ID = '711643'  # GENERIC product ID to add to cart for all cart test 
PRODUCT_CODE_TO_SEARCH='04613521781'

#JOBLIST SEARCH PRODUCT TO ADD TO JOBLIST
SEARCH_PRODUCT_NAME = 'lamp'
SEARCH_PRODUCT_NAME_TWO = 'cable'
SEARCH_PRODUCT_NAME_LIST = ["cable","wire","bul","nai","insta","ener","light","tool","tele","com"] 

INVALID_PRODUCT_REFERENCE = "abc"
VALID_PRODUCT_REFERENCE_SINGLE = {"Product_Reference": "937843", "Product_Quantity": "1"}

#COUNTRY URL TO VERIFY JOBLIST PAGE
CURRENT_WEBSHOP_URL = 'http://10.98.0.171:9001/usg'

#Order History Data 
SEARCH_ORDER_NUMBER = 'S117081712'

#ORDER HISTORY PAGINATION DROPDOWN VALUE LOCATOR BY NAME
SELECT_VALUE = '20'

SELECT_START_DATE_CALENDER = '13-07-2016'