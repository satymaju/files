#The url details mentioned here are Development local environment for testing purpose 

#General configuration
BROWSER =  "chrome"
TENANT  =  "uki"
URL = "http://RexelQAEnv:Rexel!23@52.30.208.79"

#Users
USER = {"login": "qa_user1", "password":"12345678"}
AUTO_USER = {"login": "qa_user1", "password":"12345678"}
TRADE_ACCOUNT_USER = {"login": "qa_robot", "password":"@rexelrobo123"}


#Checkout
PAYMENT_NUMBER = '1234567890'
INVALID_PAYMENT_NUMBER = '123Sud'


#Product Data for Search
PRODUCT_CODE_TO_SEARCH='3755211'
PRODUCT_CODE_TO_SEARCH1='lamp'
SEARCH_PRODUCT_NAME = 'switches'
SEARCH_PRODUCT_NAME_LIST = ["cable","wire","bul","nai","insta","ener","light","tool","tele","com"] 	

#FAST ORDER
FAST_ORDER_PRODUCT_ID = ["partMfgCode_0","partMfgCode_1","partMfgCode_2","partMfgCode_3","partMfgCode_4","partMfgCode_5","partMfgCode_6","partMfgCode_7","partMfgCode_8","partMfgCode_9"]
FAST_ORDER_PRODUCT_QUANTITY_ID = ["quantity_0","quantity_1","quantity_2","quantity_3","quantity_4","quantity_5","quantity_6","quantity_7","quantity_8","quantity_9"]
FAST_ORDER_PRODUCT_STATUS_ID = ["status_0","status_1","status_2","status_3","status_4","status_5","status_6","status_7","status_8","status_9"]

#ORDER HISTORY PAGINATION DROPDOWN VALUE LOCATOR BY NAME
SELECT_VALUE = '20'

PRODUCT_ID = '3408310'  # GENERIC product ID to add to cart for all cart test 
PRODUCT_CODE_TO_SEARCH='04613521781'
OBSELETE_PRODUCT_CODE = '33856'
REPLACEMENT_PRODUCT_CODE = '303945'

#PASSWORD RESETTING
ACCOUNT_LOCKED_ERROR_MESSAGE = 'Your account has been locked'
WRONGPASSWORD = '1234567890'
NEWPASSWORD = '12345678'
ACCOUNT_LOCK_COUNTER = '3'